
<!DOCTYPE html>
<html lang="en-US">
<meta charset="utf-8">
<title>You will be redirected shortly</title>
<meta http-equiv="refresh" content="0; url=set-up-your-project.html">
<h1>Redirecting&hellip;</h1>
<a href="set-up-your-project.html">Click here if you are not redirected.</a>
<script>location = "set-up-your-project.html"</script>
</html>

