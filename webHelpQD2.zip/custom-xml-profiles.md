
<!DOCTYPE html>
<html lang="en-US">
<meta charset="utf-8">
<title>You will be redirected shortly</title>
<meta http-equiv="refresh" content="0; url=custom-profiles.html">
<h1>Redirecting&hellip;</h1>
<a href="custom-profiles.html">Click here if you are not redirected.</a>
<script>location = "custom-profiles.html"</script>
</html>

